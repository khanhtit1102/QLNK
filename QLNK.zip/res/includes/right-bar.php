<div class="search">
	<div class="input-field">
		<i class="material-icons prefix">search</i>
		<input id="icon_prefix" type="text" class="validate">
		<label for="icon_prefix">Any keyword you want...</label>
	</div>
</div>
<div class="images">
	<img src="http://conganbacninh.vn/Images/Post/images/slide%20anh/phai%201.jpg" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/files/hoi%20dap(1).jpg" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/files/vanban.jpg" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/images/thong-tin-quang-ba/hot-danhba.jpg" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/images/thong-tin-quang-ba/thutuchanhchinh.png" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/images/slide%20anh/phai%201.jpg" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/files/hoi%20dap(1).jpg" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/files/vanban.jpg" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/images/thong-tin-quang-ba/hot-danhba.jpg" alt="" style="width: 100%; border-radius: 10px;">
	<img src="http://conganbacninh.vn/Images/Post/images/thong-tin-quang-ba/thutuchanhchinh.png" alt="" style="width: 100%; border-radius: 10px;">
</div>
<ul class="collapsible" data-collapsible="accordion">
	<li class="active">
		<div class="collapsible-header">
			CÓ THỂ BẠN CHƯA ĐỌC 
		</div>
		<div class="collapsible-body">
			<div class="row">
				<div class="col s12 m12 l12">
					<div class="body-content">
						<ul>
							<li>
								<a href="">
									<i class="tiny material-icons left">chevron_right</i>
									<p>Thông tin về vụ bắt cóc trẻ em tại Võ Cường được đăng tải lên trên mạng xã hội (Facebook)</p>
								</a>
							</li>
							<li>
								<a href="">
									<i class="tiny material-icons left">chevron_right</i>
									<p>Thông tin về vụ bắt cóc trẻ em tại Võ Cường được đăng tải lên trên mạng xã hội (Facebook)</p>
								</a>
							</li>
							<li>
								<a href="">
									<i class="tiny material-icons left">chevron_right</i>
									<p>Thông tin về vụ bắt cóc trẻ em tại Võ Cường được đăng tải lên trên mạng xã hội (Facebook)</p>
								</a>
							</li>
							<li>
								<a href="">
									<i class="tiny material-icons left">chevron_right</i>
									<p>Thông tin về vụ bắt cóc trẻ em tại Võ Cường được đăng tải lên trên mạng xã hội (Facebook)</p>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</li>
</ul>