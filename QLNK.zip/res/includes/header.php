<ul id="dropdown1" class="dropdown-content">
	<li><a href="#!">one</a></li>
	<li><a href="#!">two</a></li>
	<li class="divider"></li>
	<li><a href="#!">three</a></li>
</ul>
<nav>
	<div class="nav-wrapper">
		<a href="#" class="brand-logo"><i class="material-icons left">spa</i>LOGO</a>
		<ul id="nav-mobile" class="right hide-on-med-and-down">
			<li><a href="">Tin tức</a></li>
			<li><a href="">Văn bản pháp luật</a></li>
			<li><a href="">Tra cứu thông tin</a></li>
			<li><a href="">Quản trị viên</a></li>
			<li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Dropdown<i class="material-icons right">arrow_drop_down</i></a></li>
		</ul>
	</div>
</nav>